package com.ppssppporter.launcher

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/** Activity tanpa UI: dipakai shortcut game di layar utama. */
class LaunchActivity : Activity() {
    companion object {
        const val EXTRA_LOCATION = "location"
        const val EXTRA_IS_URI = "is_uri"
        const val EXTRA_TITLE = "title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loc = intent.getStringExtra(EXTRA_LOCATION)
        if (loc != null) {
            val game = Game(
                intent.getStringExtra(EXTRA_TITLE) ?: "Game",
                loc, 0L, intent.getBooleanExtra(EXTRA_IS_URI, false), ""
            )
            val err = Launcher.launch(this, game)
            if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
