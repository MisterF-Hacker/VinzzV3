package com.ppssppporter.launcher

import android.graphics.Typeface
import android.text.TextUtils
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GameAdapter(
    private val onClick: (Game) -> Unit,
    private val onLong: (Game) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    private var items: List<Game> = emptyList()

    fun submit(list: List<Game>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val box: LinearLayout, val title: TextView, val sub: TextView) : RecyclerView.ViewHolder(box)

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val title = TextView(ctx).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val sub = TextView(ctx).apply {
            textSize = 12f
            alpha = 0.7f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            val tv = TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
            addView(title)
            addView(sub)
        }
        return VH(box, title, sub)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val g = items[position]
        holder.title.text = g.title
        val fmt = if (g.format.isBlank()) "?" else g.format
        holder.sub.text = fmt + " • " + formatSize(g.sizeBytes) + " • " +
            (if (g.isUri) "dipilih manual" else "folder Game")
        holder.box.setOnClickListener { onClick(g) }
        holder.box.setOnLongClickListener { onLong(g); true }
    }
}
