package com.ppssppporter.launcher

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: GameAdapter
    private lateinit var banner: TextView
    private lateinit var bannerBtn: Button
    private lateinit var empty: TextView
    private var bannerAction: (() -> Unit)? = null
    private var gameCount = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            Prefs.addPicked(this, u.toString())
        }
        if (uris.isNotEmpty()) refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "PPSSPP Porter"

        banner = TextView(this).apply {
            setPadding(dp(16), dp(12), dp(16), dp(4))
            visibility = View.GONE
        }
        bannerBtn = Button(this).apply {
            visibility = View.GONE
            setOnClickListener { bannerAction?.invoke() }
        }
        adapter = GameAdapter({ play(it) }, { showGameMenu(it) })
        val list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            this.adapter = this@MainActivity.adapter
        }
        empty = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            text = "Belum ada game.\n\nTaruh file game (.iso, .cso, .pbp, .chd, dll.) ke folder:\n" +
                Storage.gameDir.absolutePath + "\n\natau ketuk \"Tambah game\" di menu."
        }
        val frame = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(banner)
            addView(bannerBtn)
            addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        setContentView(root)

        if (!Prefs.helpSeen(this)) {
            Prefs.setHelpSeen(this)
            showHelp()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        updateBanner()
        val access = Storage.hasAccess(this)
        if (access) Storage.ensureFolders()
        val ctx = applicationContext
        thread {
            val found = ArrayList<Game>()
            if (access) found.addAll(Storage.scanGames())
            for (u in Prefs.pickedUris(ctx)) Storage.queryUri(ctx, u)?.let { found.add(it) }
            found.sortBy { it.title.lowercase() }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    gameCount = found.size
                    adapter.submit(found)
                    empty.visibility = if (found.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun updateBanner() {
        when {
            !Storage.hasAccess(this) -> showBanner(
                "Izin penyimpanan dibutuhkan untuk membuat folder Game, Textures, dan Savedata.",
                "Beri izin"
            ) { requestStorage() }
            Launcher.findPackage(this) == null -> showBanner(
                "PPSSPP belum terpasang. Aplikasi ini hanya peluncur; emulatornya tetap PPSSPP.",
                "Unduh PPSSPP"
            ) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ppsspp.org/download/")))
                } catch (_: Exception) {
                    Toast.makeText(this, "Buka ppsspp.org di browser", Toast.LENGTH_LONG).show()
                }
            }
            else -> {
                banner.visibility = View.GONE
                bannerBtn.visibility = View.GONE
                bannerAction = null
            }
        }
    }

    private fun showBanner(msg: String, btn: String, action: () -> Unit) {
        banner.text = msg
        bannerBtn.text = btn
        bannerAction = action
        banner.visibility = View.VISIBLE
        bannerBtn.visibility = View.VISIBLE
    }

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                1
            )
        }
    }

    private fun play(g: Game) {
        val err = Launcher.launch(this, g)
        if (err != null) AlertDialog.Builder(this).setTitle("Tidak bisa menjalankan").setMessage(err)
            .setPositiveButton("OK", null).show()
    }

    private fun showGameMenu(g: Game) {
        val labels = mutableListOf("Mainkan", "Buat ikon game di layar utama")
        if (g.isUri) labels.add("Hapus dari daftar")
        AlertDialog.Builder(this).setTitle(g.title)
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> play(g)
                    1 -> if (!Shortcuts.pin(this, g))
                        Toast.makeText(this, "Launcher HP ini tidak mendukung shortcut", Toast.LENGTH_LONG).show()
                    2 -> { Prefs.removePicked(this, g.location); refresh() }
                }
            }.show()
    }

    private fun showFolders() {
        val msg = "Game ($gameCount ditemukan)\n" + Storage.gameDir.absolutePath +
            "\n\nTextures (per game: TEXTURES/<ID game>/)\n" + Storage.texturesDir.absolutePath +
            "\n\nSavedata\n" + Storage.savedataDir.absolutePath +
            "\n\nFormat didukung: " + Storage.formats.joinToString(", ") { it.uppercase() }
        AlertDialog.Builder(this).setTitle("Folder").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun showHelp() {
        val msg = "1. Pasang PPSSPP, buka sekali, lalu pilih penyimpanan di /sdcard/PSP.\n" +
            "2. Beri izin \"Akses semua file\" ke aplikasi ini.\n" +
            "3. Salin game ke folder Game, atau pakai menu \"Tambah game\".\n" +
            "4. Ketuk game untuk bermain. Tekan lama untuk membuat ikon di layar utama.\n" +
            "5. Atur grafik & kontrol dari menu. Tutup PPSSPP sepenuhnya sebelum mengubah setelan, " +
            "agar perubahan tidak tertimpa."
        AlertDialog.Builder(this).setTitle("Cara pakai").setMessage(msg).setPositiveButton("Mengerti", null).show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Tambah game").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 2, 1, "Grafik & performa")
        menu.add(0, 3, 2, "Kontrol & panduan tombol")
        menu.add(0, 4, 3, "Info folder")
        menu.add(0, 5, 4, "Bantuan")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> picker.launch(arrayOf("*/*"))
            2 -> startActivity(Intent(this, GraphicsActivity::class.java))
            3 -> startActivity(Intent(this, ControlsActivity::class.java))
            4 -> showFolders()
            5 -> showHelp()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
