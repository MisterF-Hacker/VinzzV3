package com.ppssppporter.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object Launcher {
    private val PACKAGES = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold")
    private const val ACTIVITY = "org.ppsspp.ppsspp.PpssppActivity"

    fun findPackage(ctx: Context): String? = PACKAGES.firstOrNull { p ->
        try {
            ctx.packageManager.getPackageInfo(p, 0); true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun buildUri(ctx: Context, game: Game): Uri {
        if (game.isUri) return Uri.parse(game.location)
        val f = File(game.location)
        if (!f.exists()) throw IllegalStateException("file tidak ditemukan")
        val special = game.location.any { it == '%' || it == '#' || it == '?' }
        return if (Prefs.launchMode(ctx) == Prefs.MODE_PROVIDER || special)
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        else
            Uri.parse(game.location)
    }

    /** Mengembalikan null jika sukses, atau pesan error. */
    fun launch(ctx: Context, game: Game): String? {
        val pkg = findPackage(ctx)
            ?: return "PPSSPP belum terpasang. Pasang dari Play Store atau ppsspp.org."
        val data = try {
            buildUri(ctx, game)
        } catch (e: Exception) {
            return "Game tidak bisa dibuka: ${e.message}"
        }
        val flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        return try {
            val i = Intent(Intent.ACTION_VIEW).setClassName(pkg, ACTIVITY).setData(data).addFlags(flags)
            ctx.startActivity(i)
            null
        } catch (e: ActivityNotFoundException) {
            try {
                val i = Intent(Intent.ACTION_VIEW).setPackage(pkg).setData(data).addFlags(flags)
                ctx.startActivity(i)
                null
            } catch (e2: Exception) {
                "PPSSPP tidak menerima game ini: ${e2.message}"
            }
        } catch (e: Exception) {
            "Gagal menjalankan: ${e.message}"
        }
    }
}
