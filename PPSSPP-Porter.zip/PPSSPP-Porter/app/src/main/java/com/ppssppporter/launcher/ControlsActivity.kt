package com.ppssppporter.launcher

import android.widget.Button

class ControlsActivity : BasePage() {
    override fun build() {
        title = "Kontrol & panduan tombol"
        storageStatus()

        header("Tombol layar sentuh")
        iniSwitch(
            "Tampilkan tombol sentuh",
            "Matikan jika kamu memakai gamepad/controller Bluetooth.",
            "Control", "ShowTouchControls", true
        )
        iniSeek(
            "Transparansi tombol",
            "0 = hampir tak terlihat, 100 = solid. Tombol lebih transparan tidak menutupi layar game.",
            "Control", "TouchButtonOpacity", 0, 100, 65, "%"
        )
        iniChoice(
            "Gaya tombol",
            "Klasik: tombol bulat penuh. Tipis: garis tipis, lebih minimalis.",
            "Control", "TouchButtonStyle",
            listOf("Klasik", "Tipis"), listOf("0", "1"), "0"
        )
        iniSwitch("Getar saat menekan tombol", "Umpan balik haptic pada tombol layar.", "Control", "HapticFeedback", true)

        val open = Button(this).apply {
            text = "Buka PPSSPP (atur posisi & ukuran tombol)"
            setOnClickListener {
                val pkg = Launcher.findPackage(this@ControlsActivity)
                val i = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                if (i != null) startActivity(i) else toast("PPSSPP belum terpasang")
            }
        }
        content.addView(open)
        content.addView(note("Posisi dan ukuran tiap tombol diatur di dalam PPSSPP (lihat panduan di bawah)."))

        header("Panduan: tombol PSP")
        content.addView(note(
            "D-Pad (↑ ↓ ← →) → gerak / navigasi menu. Gamepad: D-Pad.\n" +
                "Analog → gerak 360°. Gamepad: stik kiri.\n" +
                "✕ Cross → konfirmasi (game Barat). Gamepad: A.\n" +
                "○ Circle → batal / kembali (game Barat). Gamepad: B.\n" +
                "□ Square → aksi. Gamepad: X.\n" +
                "△ Triangle → aksi / menu. Gamepad: Y.\n" +
                "L / R → tombol bahu. Gamepad: L1 / R1 (LB / RB).\n" +
                "Start / Select → menu game / pilih. Gamepad: Start / Select (Back).\n\n" +
                "Catatan: di banyak game Jepang fungsi ○ dan ✕ tertukar (○ = konfirmasi)."
        ).apply { textSize = 13f; alpha = 0.85f })

        header("Panduan: kustomisasi tombol")
        content.addView(note(
            "1. Ketuk \"Buka PPSSPP\" di atas.\n" +
                "2. Settings → Controls → \"Edit touch control layout\" (tata letak kontrol sentuh).\n" +
                "3. Seret tombol ke posisi yang nyaman, atur ukuran, lalu Save.\n" +
                "4. \"Control mapping\" untuk memetakan ulang tombol gamepad / keyboard.\n" +
                "5. \"Combo key\" untuk membuat satu tombol yang menekan beberapa tombol sekaligus.\n" +
                "6. Menu jeda: tombol Back Android atau ikon jeda di layar.\n\n" +
                "Setelan di halaman ini ditulis ke ppsspp.ini dan berlaku setelah PPSSPP dibuka ulang."
        ).apply { textSize = 13f; alpha = 0.85f })
    }
}
