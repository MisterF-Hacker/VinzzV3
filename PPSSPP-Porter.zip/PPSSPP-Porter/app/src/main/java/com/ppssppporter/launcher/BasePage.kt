package com.ppssppporter.launcher

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Halaman pengaturan yang menulis langsung ke ppsspp.ini. Tiap opsi punya teks panduan di bawahnya. */
abstract class BasePage : AppCompatActivity() {
    protected lateinit var content: LinearLayout
    protected lateinit var ini: PpssppIni

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(32))
        }
        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        content.removeAllViews()
        ini = PpssppIni(Storage.iniFile)
        ini.load()
        build()
    }

    abstract fun build()

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    protected fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    protected fun header(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(24), 0, dp(4))
        })
    }

    protected fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setPadding(0, dp(12), 0, 0)
    }

    protected fun note(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        alpha = 0.7f
        setPadding(0, dp(2), 0, dp(4))
    }

    protected fun storageStatus() {
        val msg = if (!Storage.hasAccess(this))
            "⚠ Izin \"Akses semua file\" belum aktif. Setelan tidak bisa disimpan. Aktifkan dari layar utama."
        else
            "File setelan: " + Storage.iniFile.absolutePath +
                (if (ini.exists()) "" else "\n(belum ada; akan dibuat. Buka PPSSPP sekali agar setelan lengkap)")
        content.addView(note(msg))
    }

    protected fun writeIni(section: String, key: String, value: String) {
        ini.set(section, key, value)
        if (!ini.save()) toast("Gagal menyimpan. Pastikan izin \"Akses semua file\" aktif.")
    }

    protected fun choiceCore(title: String, help: String, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        content.addView(label(title))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(selected.coerceIn(0, labels.size - 1), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onSelect(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        content.addView(sp)
        content.addView(note(help))
    }

    protected fun iniChoice(
        title: String, help: String, section: String, key: String,
        labels: List<String>, values: List<String>, default: String
    ) {
        val cur = (ini.get(section, key) ?: default).trim().substringBefore(' ')
        val idx = values.indexOfFirst { it.substringBefore(' ') == cur }.let { if (it < 0) 0 else it }
        choiceCore(title, help, labels, idx) { pos -> writeIni(section, key, values[pos]) }
    }

    protected fun iniSwitch(title: String, help: String, section: String, key: String, default: Boolean) {
        val cur = ini.get(section, key)?.lowercase()?.let { it.startsWith("true") || it == "1" } ?: default
        val sw = SwitchCompat(this).apply {
            text = title
            isChecked = cur
            setPadding(0, dp(12), 0, 0)
            setOnCheckedChangeListener { _, checked -> writeIni(section, key, if (checked) "True" else "False") }
        }
        content.addView(sw)
        content.addView(note(help))
    }

    protected fun iniSeek(
        title: String, help: String, section: String, key: String,
        lo: Int, hi: Int, default: Int, unit: String = ""
    ) {
        val cur = (ini.get(section, key)?.trim()?.substringBefore(' ')?.toIntOrNull() ?: default).coerceIn(lo, hi)
        val lbl = label("$title: $cur$unit")
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = cur - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                lbl.text = "$title: ${p + lo}$unit"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (s != null) writeIni(section, key, (s.progress + lo).toString())
            }
        })
        content.addView(lbl)
        content.addView(bar)
        content.addView(note(help))
    }
}
