package com.ppssppporter.launcher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import java.io.File

data class Game(
    val title: String,
    val location: String,   // path file, atau string content:// Uri
    val sizeBytes: Long,
    val isUri: Boolean,
    val format: String
)

object Storage {
    private val sd: File get() = Environment.getExternalStorageDirectory()

    /** Folder game milik launcher: /sdcard/PPSSPP-Launcher/Game */
    val gameDir: File get() = File(File(sd, "PPSSPP-Launcher"), "Game")

    /** Folder memory stick bawaan PPSSPP: /sdcard/PSP */
    val pspDir: File get() = File(sd, "PSP")
    val texturesDir: File get() = File(pspDir, "TEXTURES")
    val savedataDir: File get() = File(pspDir, "SAVEDATA")
    val systemDir: File get() = File(pspDir, "SYSTEM")
    val iniFile: File get() = File(systemDir, "ppsspp.ini")

    val formats = setOf("iso", "cso", "zso", "pbp", "chd", "elf", "prx")

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    fun ensureFolders(): Boolean =
        listOf(gameDir, texturesDir, savedataDir, systemDir).map { it.exists() || it.mkdirs() }.all { it }

    fun scanGames(): List<Game> {
        if (!gameDir.exists()) return emptyList()
        return gameDir.walkTopDown()
            .maxDepth(5)
            .filter { it.isFile && it.extension.lowercase() in formats }
            .map { f ->
                val title = if (f.name.equals("EBOOT.PBP", ignoreCase = true))
                    (f.parentFile?.name ?: f.nameWithoutExtension) else f.nameWithoutExtension
                Game(title, f.absolutePath, f.length(), false, f.extension.uppercase())
            }
            .toList()
    }

    fun queryUri(ctx: Context, uriStr: String): Game? {
        return try {
            val uri = Uri.parse(uriStr)
            ctx.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0) ?: "game"
                    val size = if (c.isNull(1)) 0L else c.getLong(1)
                    Game(name.substringBeforeLast('.'), uriStr, size, true, name.substringAfterLast('.', "").uppercase())
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
