package com.ppssppporter.launcher

import android.content.Context

object Prefs {
    const val MODE_PATH = 0
    const val MODE_PROVIDER = 1

    private fun sp(ctx: Context) = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun launchMode(ctx: Context): Int = sp(ctx).getInt("launch_mode", MODE_PROVIDER)
    fun setLaunchMode(ctx: Context, v: Int) = sp(ctx).edit().putInt("launch_mode", v).apply()

    fun pickedUris(ctx: Context): Set<String> =
        HashSet(sp(ctx).getStringSet("picked", emptySet()) ?: emptySet())

    fun addPicked(ctx: Context, uri: String) {
        val s = pickedUris(ctx).toMutableSet(); s.add(uri)
        sp(ctx).edit().putStringSet("picked", s).apply()
    }

    fun removePicked(ctx: Context, uri: String) {
        val s = pickedUris(ctx).toMutableSet(); s.remove(uri)
        sp(ctx).edit().putStringSet("picked", s).apply()
    }

    fun helpSeen(ctx: Context): Boolean = sp(ctx).getBoolean("help_seen", false)
    fun setHelpSeen(ctx: Context) = sp(ctx).edit().putBoolean("help_seen", true).apply()
}
