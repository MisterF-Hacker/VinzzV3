package com.ppssppporter.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** "Porting" ringan: ikon game sendiri di layar utama yang langsung membuka PPSSPP. */
object Shortcuts {
    fun pin(ctx: Context, game: Game): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return false
        val intent = Intent(ctx, LaunchActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            putExtra(LaunchActivity.EXTRA_LOCATION, game.location)
            putExtra(LaunchActivity.EXTRA_IS_URI, game.isUri)
            putExtra(LaunchActivity.EXTRA_TITLE, game.title)
        }
        val info = ShortcutInfoCompat.Builder(ctx, "game_" + game.location.hashCode())
            .setShortLabel(game.title.take(20))
            .setLongLabel(game.title)
            .setIcon(IconCompat.createWithBitmap(makeIcon(game.title)))
            .setIntent(intent)
            .build()
        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }

    private fun makeIcon(title: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hue = ((title.hashCode() and 0x7fffffff) % 360).toFloat()
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.55f))
        }
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 40f, 40f, bg)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 110f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        val letter = title.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "P"
        c.drawText(letter, size / 2f, size / 2f - (tp.descent() + tp.ascent()) / 2f, tp)
        return bmp
    }
}
