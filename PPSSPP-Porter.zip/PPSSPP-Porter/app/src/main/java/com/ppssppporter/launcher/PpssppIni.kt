package com.ppssppporter.launcher

import java.io.File

/** Editor sederhana untuk ppsspp.ini; key lain dibiarkan apa adanya. */
class PpssppIni(private val file: File) {
    private val lines = mutableListOf<String>()

    fun load() {
        lines.clear()
        try {
            if (file.exists()) lines.addAll(file.readLines())
        } catch (_: Exception) {
        }
    }

    fun exists(): Boolean = file.exists()

    private fun sectionRange(section: String): IntRange? {
        val start = lines.indexOfFirst { it.trim() == "[$section]" }
        if (start < 0) return null
        var end = lines.size - 1
        for (i in start + 1 until lines.size) {
            if (lines[i].trim().startsWith("[")) { end = i - 1; break }
        }
        return start..end
    }

    private fun keyOf(line: String): String? {
        val t = line.trimStart()
        if (t.startsWith("#") || t.startsWith(";")) return null
        val eq = t.indexOf('=')
        if (eq < 0) return null
        return t.substring(0, eq).trim()
    }

    fun get(section: String, key: String): String? {
        val r = sectionRange(section) ?: return null
        for (i in (r.first + 1)..r.last) {
            if (keyOf(lines[i]) == key) return lines[i].substringAfter('=').trim()
        }
        return null
    }

    fun set(section: String, key: String, value: String) {
        val r = sectionRange(section)
        if (r == null) {
            if (lines.isNotEmpty() && lines.last().isNotBlank()) lines.add("")
            lines.add("[$section]")
            lines.add("$key = $value")
            return
        }
        for (i in (r.first + 1)..r.last) {
            if (keyOf(lines[i]) == key) { lines[i] = "$key = $value"; return }
        }
        var pos = r.last
        while (pos > r.first && lines[pos].isBlank()) pos--
        lines.add(pos + 1, "$key = $value")
    }

    fun save(): Boolean = try {
        file.parentFile?.mkdirs()
        file.writeText(lines.joinToString("\n") + "\n")
        true
    } catch (e: Exception) {
        false
    }
}
