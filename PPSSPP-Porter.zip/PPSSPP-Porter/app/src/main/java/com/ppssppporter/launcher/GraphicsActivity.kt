package com.ppssppporter.launcher

class GraphicsActivity : BasePage() {
    override fun build() {
        title = "Grafik & performa"
        storageStatus()

        header("Driver grafis")
        iniChoice(
            "Backend rendering",
            "Vulkan: umumnya lebih cepat dan hemat baterai di HP modern. OpenGL: lebih kompatibel di HP/GPU lama. " +
                "Jika game glitch atau crash, coba ganti ke yang lain.",
            "Graphics", "GraphicsBackend",
            listOf("Vulkan", "OpenGL"), listOf("3 (VULKAN)", "0 (OPENGL)"), "3 (VULKAN)"
        )

        header("Kualitas gambar")
        iniChoice(
            "Resolusi internal",
            "Semakin tinggi semakin tajam tetapi lebih berat. Mulai dari 2x; turunkan jika patah-patah.",
            "Graphics", "InternalResolution",
            listOf("Otomatis", "1x (480x272)", "2x (960x544)", "3x", "4x", "5x", "6x", "8x", "10x"),
            listOf("0", "1", "2", "3", "4", "5", "6", "8", "10"), "0"
        )
        iniChoice(
            "Anisotropic filtering",
            "Membuat tekstur di sudut miring lebih tajam. Dampak performa kecil sampai sedang.",
            "Graphics", "AnisotropyLevel",
            listOf("Mati", "2x", "4x", "8x", "16x"), listOf("0", "1", "2", "3", "4"), "0"
        )
        iniChoice(
            "Penskalaan tekstur",
            "Memperhalus tekstur beresolusi rendah. Level tinggi sangat berat; pakai hanya di HP kuat.",
            "Graphics", "TexScalingLevel",
            listOf("Mati", "2x", "3x", "4x", "5x"), listOf("1", "2", "3", "4", "5"), "1"
        )

        header("Performa")
        iniChoice(
            "Mode CPU",
            "JIT paling cepat dan disarankan. Interpreter hanya untuk debugging (sangat lambat).",
            "CPU", "CPUCore",
            listOf("JIT (disarankan)", "IR Interpreter", "Interpreter"), listOf("1", "2", "0"), "1"
        )
        iniChoice(
            "Frame skip",
            "Melewati sebagian frame agar game ringan lebih cepat. Gambar bisa terlihat kurang mulus.",
            "Graphics", "FrameSkip",
            listOf("Mati", "1", "2", "3", "4", "5"), listOf("0", "1", "2", "3", "4", "5"), "0"
        )
        iniSwitch("Frame skip otomatis", "Frame dilewati hanya saat game melambat.", "Graphics", "AutoFrameSkip", false)
        iniSwitch("VSync", "Mengurangi sobekan gambar. Matikan jika ingin FPS maksimal.", "Graphics", "VSync", true)
        iniChoice(
            "Tampilkan FPS",
            "Menampilkan angka FPS dan kecepatan emulasi di layar.",
            "Graphics", "ShowFPSCounter",
            listOf("Mati", "Tampil"), listOf("0", "3"), "0"
        )

        header("Tekstur kustom & cheat")
        iniSwitch(
            "Ganti tekstur (texture pack)",
            "Pakai tekstur dari folder Textures: " + Storage.texturesDir.absolutePath + "/<ID game>/",
            "Graphics", "ReplaceTextures", true
        )
        iniSwitch(
            "Simpan tekstur baru (dump)",
            "Menyimpan tekstur game ke folder Textures agar bisa kamu edit. Matikan setelah selesai, karena memperlambat game.",
            "Graphics", "SaveNewTextures", false
        )
        iniSwitch("Aktifkan cheat", "Memakai file cheat.db / cheat per game di PPSSPP.", "General", "EnableCheats", false)

        header("Peluncuran")
        choiceCore(
            "Cara mengirim game ke PPSSPP",
            "FileProvider (disarankan) paling stabil di Android 11+. Pakai \"Path langsung\" hanya jika game tidak mau terbuka.",
            listOf("FileProvider (disarankan)", "Path langsung"),
            if (Prefs.launchMode(this) == Prefs.MODE_PROVIDER) 0 else 1
        ) { pos -> Prefs.setLaunchMode(this, if (pos == 0) Prefs.MODE_PROVIDER else Prefs.MODE_PATH) }

        content.addView(note("Tutup PPSSPP sepenuhnya (hapus dari recent apps) sebelum mengubah setelan agar tidak tertimpa."))
    }
}
