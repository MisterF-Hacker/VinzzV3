# PPSSPP Porter (Launcher)

Aplikasi Android ringan yang mengelola game PSP dan menjalankannya lewat PPSSPP yang sudah terpasang.
Aplikasi ini **bukan emulator**; emulatornya tetap PPSSPP (GPL, https://www.ppsspp.org).
Gunakan hanya game yang kamu miliki secara sah.

## Fitur
- Folder otomatis (dibuat saat izin diberikan):
  - Game: `/sdcard/PPSSPP-Launcher/Game`
  - Textures: `/sdcard/PSP/TEXTURES` (per game: `TEXTURES/<ID game>/`)
  - Savedata: `/sdcard/PSP/SAVEDATA`
- Format: ISO, CSO, ZSO, PBP, CHD, ELF, PRX (scan folder Game + "Tambah game" dari lokasi mana pun)
- Grafik: backend Vulkan / OpenGL, resolusi internal, anisotropic, penskalaan tekstur, mode CPU, frame skip, VSync, FPS counter, texture replace/dump, cheat
- Kontrol: tampil/sembunyi tombol sentuh, transparansi, gaya, getar, plus panduan peta tombol dan cara kustomisasi layout
- Tekan lama sebuah game -> "Buat ikon game di layar utama" (ikon per game yang langsung membuka PPSSPP)

## Cara build APK
**A. Android Studio**: File -> Open -> pilih folder ini -> tunggu Gradle sync -> Build -> Build APK(s).
APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

**B. Tanpa komputer (GitHub Actions)**: upload isi folder ini ke repo GitHub baru -> tab Actions ->
"Build APK" -> unduh artifact `PPSSPP-Porter-apk`.

## Setup di HP
1. Pasang PPSSPP, buka sekali, pilih penyimpanan memory stick di `/sdcard/PSP`.
2. Buka PPSSPP Porter -> beri izin "Akses semua file".
3. Taruh game di folder Game, lalu ketuk untuk bermain.

## Catatan jujur (belum diuji di perangkat)
Kode ini ditulis tanpa Android SDK sehingga **belum pernah dikompilasi atau dites**. Kemungkinan perlu perbaikan kecil.
- Peluncuran memakai intent ACTION_VIEW ke `org.ppsspp.ppsspp/.PpssppActivity` (cara yang dipakai frontend seperti ES-DE). Jika game tidak terbuka, ganti "Cara mengirim game" di Grafik & performa.
- Nama key `ppsspp.ini` ditulis dari ingatan dan bisa berbeda antar versi PPSSPP. Jika suatu opsi tidak berpengaruh, ubah dari dalam PPSSPP.
- Jika PPSSPP memakai memory stick di lokasi selain `/sdcard/PSP`, setelan launcher tidak akan terbaca.
- Izin "Akses semua file" dibatasi Google Play; aplikasi ini ditujukan untuk sideload.
